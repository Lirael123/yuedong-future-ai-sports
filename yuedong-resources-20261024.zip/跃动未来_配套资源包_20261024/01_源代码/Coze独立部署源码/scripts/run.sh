#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_DIR"

deploy_port="${DEPLOY_RUN_PORT:-5000}"

export DEPLOY_RUN_PORT="$deploy_port"
export COZE_SITE_ORIGINS="https://6zmbbb8g9t.coze.site"
exec node scripts/hosting-server.mjs
