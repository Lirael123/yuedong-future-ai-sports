#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_DIR"

preview_port=5000
if [[ -f .preview ]]; then
  configured_port=$(awk -F '[ =]+' '/^expose_port/ {gsub(/[^0-9]/, "", $2); print $2; exit}' .preview)
  preview_port="${configured_port:-5000}"
fi

if [[ ! "$preview_port" =~ ^[0-9]+$ ]] || (( 10#$preview_port < 1 || 10#$preview_port > 65535 )); then
  echo "Invalid Coze preview expose_port" >&2
  exit 1
fi

export DEPLOY_RUN_PORT="$preview_port"
export COZE_SITE_ORIGINS="https://a669fe12-412c-4bb8-955b-d0eae0f583ec.dev.coze.site"
exec node scripts/hosting-server.mjs
