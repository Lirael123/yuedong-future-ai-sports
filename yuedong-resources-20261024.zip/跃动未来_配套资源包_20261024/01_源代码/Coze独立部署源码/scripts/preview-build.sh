#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_DIR"

export NODE_USE_ENV_PROXY=1
export COREPACK_NPM_REGISTRY=https://registry.npmmirror.com
export npm_config_registry=https://registry.npmmirror.com/

corepack pnpm install --frozen-lockfile --prefer-offline --reporter=append-only
corepack pnpm build
