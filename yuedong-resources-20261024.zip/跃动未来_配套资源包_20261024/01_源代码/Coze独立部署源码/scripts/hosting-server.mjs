import { createServer } from 'node:http';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import serveHandler from 'serve-handler';
import coachWorker from '../coze-proxy/worker.js';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..', 'dist');
const port = Number(process.env.DEPLOY_RUN_PORT || 5000);
const workflowUrl = process.env.COZE_CODING_WORKFLOW_URL || 'https://y26823vr3w.coze.site/run';
const maxBody = 4096;
const windowMs = 60_000;
const calls = new Map();

function sameSiteOrigin(request) {
  const origin = request.headers.origin || '';
  // Coze's production gateway can replace Host with an internal upstream host.
  // Match exact public origins instead of trusting a forwarded Host header.
  const configured = String(process.env.COZE_SITE_ORIGINS || '').split(',').map(s => s.trim());
  const allowed = configured.filter(site => {
    try {
      const parsed = new URL(site);
      return parsed.protocol === 'https:' && parsed.origin === site &&
        /^[a-z0-9-]+(?:\.[a-z0-9-]+)*\.coze\.site$/.test(parsed.hostname);
    } catch { return false; }
  });
  return allowed.includes(origin) ? origin : '';
}

function error(response, status, message) {
  response.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
  response.end(JSON.stringify({error:message}));
}

async function readBody(request) {
  if (Number(request.headers['content-length'] || 0) > maxBody) return null;
  const chunks = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > maxBody) return null;
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

function withinLimit(request) {
  const key = request.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const recent = (calls.get(key) || []).filter(time => now - time < windowMs);
  if (recent.length >= 20) return false;
  recent.push(now);
  calls.set(key, recent);
  if (calls.size > 1000) for (const [ip, times] of calls) if (now - times.at(-1) >= windowMs) calls.delete(ip);
  return true;
}

const server = createServer(async (request, response) => {
  try {
    const path = new URL(request.url || '/', 'http://localhost').pathname;
    if (path === '/health' && request.method === 'GET') {
      response.writeHead(200, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});
      response.end(JSON.stringify({status:'running'}));
      return;
    }
    if (path !== '/coach') {
      await serveHandler(request, response, {
        public:root, directoryListing:false, cleanUrls:false,
        rewrites:[{source:'/',destination:'/index.html'}]
      });
      return;
    }
    const origin = sameSiteOrigin(request);
    if (!origin) return error(response, 403, '访问来源未授权。');
    if (request.method !== 'POST') return error(response, 405, '仅支持 POST。');
    if (!withinLimit(request)) return error(response, 429, '请求过于频繁，请稍后再试。');
    const body = await readBody(request);
    if (!body) return error(response, 413, '请求内容过长。');
    const workerRequest = new Request(`${origin}/coach`, {
      method:'POST', headers:{Origin:origin,'Content-Type':request.headers['content-type'] || '', 'Content-Length':String(body.length)}, body
    });
    const result = await coachWorker.fetch(workerRequest, {
      ALLOWED_ORIGIN:origin,
      COZE_CODING_WORKFLOW_URL:workflowUrl,
      COZE_WORKLOAD_API_TOKEN:process.env.COZE_WORKLOAD_API_TOKEN,
      COZE_API_TOKEN:process.env.COZE_API_TOKEN
    });
    response.writeHead(result.status, Object.fromEntries(result.headers));
    response.end(Buffer.from(await result.arrayBuffer()));
  } catch {
    if (!response.headersSent) error(response, 500, '服务暂不可用。');
    else response.end();
  }
});

server.listen(port, '0.0.0.0');
