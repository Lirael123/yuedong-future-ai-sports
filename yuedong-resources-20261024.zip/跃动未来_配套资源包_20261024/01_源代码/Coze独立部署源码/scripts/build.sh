#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_DIR"

# The Coze production builder uses Node's native fetch for Corepack. Respect
# its configured HTTPS proxy when downloading the pinned, signed pnpm package.
export NODE_USE_ENV_PROXY=1
# The production builder could not reach registry.npmjs.org. The mirror's
# pnpm tarball matched npm's published SHA-512 and Corepack verified its signature.
export COREPACK_NPM_REGISTRY=https://registry.npmmirror.com
export npm_config_registry=https://registry.npmmirror.com/

echo "Installing dependencies..."
corepack pnpm install --frozen-lockfile --prefer-offline --reporter=append-only

echo "Building frontend (prebuild prepares locked MediaPipe runtime)..."
corepack pnpm build
