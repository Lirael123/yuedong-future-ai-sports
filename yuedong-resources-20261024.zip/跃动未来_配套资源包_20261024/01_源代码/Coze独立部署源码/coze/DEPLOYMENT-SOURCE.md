# 独立 Coze 部署源

此私有仓库从原仓库 feature/coze-hosting-deployment 的已验证提交同步，保留原始代码和历史。

- 本仓库 main 用于扣子 GitHub 导入；原仓库 main 与 Pages 仍独立保留。
- .env.production 只设置非机密 VITE_BASE_PATH=/，npm ci 后运行 npm run build 即为根路径产物。
- 原 Pages 发布 job 增加原仓库身份条件，在此仓库不会触发 Pages 正式部署。
- Coze 工作流与接口未实测通过前不发布为完整上线版本；Token 只保存在服务端。
- 后续在原仓库功能分支完成修改、测试及提交，再将已验证提交同步到此仓库 main；不要覆盖原仓库 main。

## 平台运行脚本

- `scripts/build.sh` 和预览安装均使用 `pnpm install --frozen-lockfile`，从保留的 npm 锁导入 pnpm 锁，MediaPipe 固定为 0.10.21。
- `serve@14.2.4` 为已锁定运行依赖；启动脚本直接调用已安装文件，不在启动时执行 npx 下载。
- 监听 `DEPLOY_RUN_PORT`，缺省 5000；端口冲突必须报错，不自动换端口；关闭运行时更新检查。
- pnpm 11 仅批准 esbuild 的构建脚本（`pnpm-workspace.yaml`）；原分析依赖的 npm 版本与完整性摘要均未改变。
- 已在本地 Node 22/pnpm 11 实际冻结安装、类型/业务/4项MediaPipe/13项代理测试、生产构建、安装服务器的桌面和手机尺寸PWA smoke、模型/WASM/MP4 Range响应及404验证通过。该启动脚本的Coze端重验仍需执行。

## 可重复的包管理器版本

Coze 默认 pnpm 9.15.9 无法读取当前 allowBuilds 配置。已在 package.json 固定 packageManager 为 pnpm@11.25.0，所有平台构建/开发脚本直接通过 corepack pnpm 调用。部署机器须保留 Node 24 和 Corepack；无需全局升级 pnpm、临时 PATH 包装或更改分析依赖。Corepack 下载仍保留 TLS/签名验证。

当前 Codex Node 22 运行在环境代理后，Corepack 需 NODE_USE_ENV_PROXY=1 和可写的 COREPACK_HOME；这是本地启动配置，不是前端变量或生产密钥。实际以固定版本执行 build.sh 和 preview-build.sh 通过，锁文件未改变；另实测端口占用时 preview-run.sh 以1退出并保留已有监听服务。
