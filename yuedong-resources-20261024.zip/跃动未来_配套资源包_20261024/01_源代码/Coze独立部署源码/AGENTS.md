# 跃动未来 deployment and maintenance

This repository contains an existing React/TypeScript/Vite/PWA application. Reuse
the application in `src/`; do not generate a replacement website, change its visual
design, remove existing code, or substitute the fixed reference video.

- Runtime: Node.js 22 and npm. Install with `npm ci` and preserve the lockfile.
- `npm run dev` starts the existing Vite app on the requested platform port.
- `npm run build` produces `dist`. Its prebuild copies the exact locked MediaPipe
  WASM files and verifies the committed model checksum. Do not disable checks.
- GitHub Pages defaults to `/yuedong-future-ai-sports/`. Independent Coze hosting
  uses `VITE_BASE_PATH=/`; never change the original repository's production base
  globally to repair a separate deployment.
- Keep `public/reference/standing-long-jump-v1.mp4` and its existing motion template.
- Student videos and pose detection stay in the browser. Send only the five
  anonymous teaching fields specified in `coze/WORKFLOW.md` to the server.
- Keep Coze tokens exclusively in backend Secrets. Reuse `coze-proxy/worker.js`
  for `/coach`; do not embed tokens or OAuth credentials in Vite variables.
- A configured URL or project ID does not prove a live workflow. Test the real
  endpoint and preserve explicit errors; do not fabricate teaching replies,
  pose landmarks, diagnostic scores, or deployment links.

Required checks before release: `npm run type-check`, `npm run test:yuedong`,
`npm run test:mediapipe`, `npm run test:coze`, production builds for both base paths,
browser smoke checks, and an authorized real standing-jump MP4 through pose
detection, four-stage diagnosis, actual Coze guidance, training and saved records.
Use a preview before publishing. Verify the actual final URL after deployment.
Run Safari checks on Safari; a narrow Chromium viewport is not Safari validation.
Keep changes in `feature/coze-hosting-deployment` in the original repository.
Never push these changes directly to its `main` or deploy its Pages automatically.

## Coze platform preview & deploy wiring

- Coze `.coze` at repo root, single-layer (`[subprojects].path = ["."]`), `sub_id` is
  stable and never edited. `project_type = "web"`, preview `0.0.0.0:5000`.
- Port comes from `.preview` (`expose_port = 5000`, git-ignored); never hardcode 5000
  in code, never touch port 9000.
- Preview entry (`[dev]`): build = `scripts/preview-build.sh` (frozen pnpm
  install + production build), run = `scripts/preview-run.sh` (same-origin
  hosting server on the port from `.preview`).
- Deploy entry (`[deploy]`): build = `scripts/build.sh` (pnpm + `pnpm build`), run =
  `scripts/run.sh` (Node hosting server, `DEPLOY_RUN_PORT` or 5000).
- Platform builds use Corepack and packageManager pnpm@11.25.0; use `corepack pnpm`, not the platform default pnpm 9. Preview uses --strictPort; do not kill an existing service to obtain a port.
- Platform builds Node/web with pnpm. Original repo keeps its npm lockfile for its own
  release; Coze-side scripts are pnpm-based and do not migrate the repo.
- `prepare-mediapipe.mjs` copies the locked MediaPipe wasm to
  `public/mediapipe/runtime/<ver>/` and verifies the committed model checksum; run it
  before any dev/build that needs pose detection assets. Never disable its checks.
